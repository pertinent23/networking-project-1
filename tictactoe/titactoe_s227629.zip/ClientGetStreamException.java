public class ClientGetStreamException extends Exception {
    public ClientGetStreamException() {
        super("Failed to get client streams");
    }
}
