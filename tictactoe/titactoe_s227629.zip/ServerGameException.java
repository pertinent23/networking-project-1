public class ServerGameException extends Exception {
    public ServerGameException(String message) {
        super(message);
    }
}
