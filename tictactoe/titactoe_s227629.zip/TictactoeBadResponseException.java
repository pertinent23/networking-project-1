public class TictactoeBadResponseException extends Exception {
    public TictactoeBadResponseException() {
        super("Bad response from server");
    }
}
